You can find information about the methods of debugging MySQL ODBC Driver at:

  https://dev.mysql.com/doc/connector-odbc/en/connector-odbc-usagenotes.html